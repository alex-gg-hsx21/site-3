const slides = document.querySelectorAll('.top__slider-item');
let currentSlide = 0;

function showNextSlide() {
  // Убираем активный класс у текущего слайда
  slides[currentSlide].classList.remove('active');
  
  // Переходим к следующему слайду, либо возвращаемся к первому
  currentSlide = (currentSlide + 1) % slides.length;
  
  // Добавляем активный класс новому слайду
  slides[currentSlide].classList.add('active');
}

// Меняем слайд каждые 3 секунды
setInterval(showNextSlide, 3000);
